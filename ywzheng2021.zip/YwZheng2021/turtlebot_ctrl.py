#!/usr/bin/env python
#encoding=utf-8
import rospy
from geometry_msgs.msg import Twist, Point, Quaternion
from nav_msgs.msg import Odometry
import tf
from math import radians, copysign, sqrt, pow, pi, atan2, fabs
from tf.transformations import euler_from_quaternion
import numpy as np

def sgn(x):
    if x > 0:
        return 1.
    elif x < 0:
        return -1.
    else:
        return 0.

def sat(x, ep):         # ep should > 0
    if fabs(x) < ep:
        return x / ep:
    elif x >= ep:
        return 1.
    else:
        return -1.

def data_saturation(x, upper, lower):
    if x >= upper:
        return upper
    elif x <= lower:
        return lower
    else:
        return x

def phi_t(t):
    K = 0.25
    return K * t

def psi_t(t):
    K = 0.5
    return K * t

bot_rate = 10.       # hz
ros_rate = 50.

class turtlebot(object):
    def __init__(self, name):
        self.name = name

        self.twist_pub = rospy.Publisher('/' + self.name + '/cmd_vel', Twist, queue_size = 1)
        self.pose_sub  = rospy.Subscriber('/' + self.name + '/odom', Odometry, self.odom_cb)

        self.x = 0
        self.y = 0
        self.yaw = 0            # in degree

        self.xr = 0
        self.yr = 0
        self.theta_r = 0        # in rads

        self.vx = 0
        self.wz = 0

        self.Kx_norminal = 0
        self.Ky_norminal = 0
        self.Kt_norminal = 0

        self.Kx_adaptive = 0
        self.Ky_adaptive = 0
        self.Kt_adaptive = 0
        self.v_hat = 0
        self.w_hat = 0
        self.v_hat_max = 1.5        # integration limit
        self.w_hat_max = 2.5

        self.Kx_robust = 0
        self.Ky_robust = 0
        self.Kt_robust = 0

        self.uv = 0
        self.uw = 0

    def odom_cb(self, data):
        # about 10Hz
        (roll, pitch, yaw) = euler_from_quaternion([data.pose.pose.orientation.x, 
                                                    data.pose.pose.orientation.y, 
                                                    data.pose.pose.orientation.z, 
                                                    data.pose.pose.orientation.w])
        self.yaw = yaw * 180. / pi
        self.x   = data.pose.pose.position.x
        self.y   = data.pose.pose.position.y


        self.update_target_vel()

    def update_target_vel(self):
        move_cmd = Twist()
        move_cmd.linear.x = self.vx
        move_cmd.angular.z =self.wz
        self.twist_pub.publish(move_cmd)

    def update_err_dynamics(self, vr, wr, dt = ros_rate):
        self.xr += vr * cos(self.theta_r) * dt
        self.yr += vr * sin(self.theta_r) * dt
        self.theta_r += wr * dt

        self.xe      =  cos(self.yaw * pi / 180.) * (self.xr - self.x) + sin(self.yaw * pi / 180.) * (self.yr - self.y)
        self.ye      = -sin(self.yaw * pi / 180.) * (self.xr - self.x) + cos(self.yaw * pi / 180.) * (self.yr - self.y)
        self.theta_e = ae1 = self.theta_r - self.yaw * pi / 180.

    def control_norminal(self, vr, wr):
        self.uv = vr * cos(self.theta_e) + self.Kx_norminal * self.xe + phi_t(t)
        self.uw = wr + vr * (self.Ky_norminal * self.ye + self.Kt_norminal * sin(self.theta_e))

        self.vx = self.uv
        self.wz = self.uw

    def control_adaptive(self, vr, wr, dt = ros_rate):
        self.v_hat += -self.xe * dt
        self.v_hat =  data_saturation(self.v_hat, self.v_hat_max, -self.v_hat_max)

        self.w_hat += -sin(self.theta_e) / self.Ky_adaptive * dt
        self.w_hat =  data_saturation(self.w_hat, self.w_hat_max, -self.w_hat_max)

        self.uv = vr * cos(self.theta_e) + self.Kx_norminal * self.xe + phi_t(t) - self.v_hat
        self.uw = wr + vr * (self.Ky_norminal * self.ye + self.Kt_norminal * sin(self.theta_e)) - self.w_hat

        self.vx = self.uv
        self.wz = self.uw

    def control_adaptive(self, vr, wr):
        self.uv = vr * cos(self.theta_e) + self.Kx_robust * self.xe + phi_t(t) * sat(self.xe, 0.25)
        self.uw = wr + vr * (self.Ky_robust * self.ye + self.Kt_robust * sin(self.theta_e)) + psi_t(t) * sat(sin(self.theta_e), 0.5)

        self.vx = self.uv
        self.wz = self.uw


def main():
    rospy.init_node('ijrr2013_ca_improv', anonymous=False)

    rate = rospy.Rate(50)	# 5Hz

    rospy.sleep(5)

    #bot_1 = turtlebot(name='amigobot_1')
    #bot_1.vx = 0.5
    #bot_1.wz = pi / 16
    time_before = 0
    time_now = rospy.Time.now().to_nsec() / 1e6 # ns -> ms


    while not rospy.is_shutdown():

        time_before = time_now
        time_now = rospy.Time.now().to_nsec() / 1e6 # ns -> ms
        dt_ = time_now - time_before
        t = time_now / 1e3                          # ms -> s

        vr = 10.;                                                                           % vr
        wr = 1.5 * 3.38321412225 * 0.24 * cos(0.24*t) / (1+(3.38321412225*sin(0.24*t))^2);  % wr

        bot_1.update_err_dynamics(vr, wr, dt=dt_)
        bot_1.control_norminal()
        
        rate.sleep()


if __name__ == '__main__':
     try:
         main()
     except rospy.ROSInterruptException:
         pass